from django.shortcuts import render, redirect
from django.contrib import messages

from .models import *
# Create your views here.


def index(request):
    ourteam = Ourteam.objects.all()

    
    if request.method == 'POST':
        name = request.POST.get("name")
        email = request.POST.get("email", None)
        phone = request.POST.get("phone")
        message = request.POST.get("message", "")
        
        Contact.objects.create(name=name, email=email, phone=phone, message=message)
        
        messages.success(request, "Your message has been submitted successfully!")
        return redirect("index")
        
        
    context = {
        'ourteam': ourteam
    }
    
    return render(request, 'index.html', context)