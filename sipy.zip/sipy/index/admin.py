from django.contrib import admin
from .models import Ourteam, Contact

class OurteamAdmin(admin.ModelAdmin):
    list_display = ('name', 'title', 'image')
    search_fields = ('name', 'title')
    list_filter = ('title',)
    ordering = ('name',)
    
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone')
    search_fields = ('name', 'email', 'phone')
    list_filter = ('name', 'email', 'phone')
    ordering = ('name',)

admin.site.register(Ourteam, OurteamAdmin)
admin.site.register(Contact, ContactAdmin)


